package notes.project.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class NotesRepository {

    private static NotesRepository instance = null;
    private NotesRepository() {}
    public static NotesRepository getInstance() {
        if (instance == null) {
            instance = new NotesRepository();
        }
        return instance;
    }

    private List<Note> notes = new ArrayList<>();

    public List<Note> getAllNotes() {
        return notes;
    }

    public List<Note> getNotesByText(String text) {

       return notes.stream().filter(element -> element.getTitle().toLowerCase().contains(text.toLowerCase())
                || element.getContent().toLowerCase().contains(text.toLowerCase())).collect(Collectors.toList());
    }

    public Note addNewNote(String title, String text) {
        Note note = new Note(new Long(notes.size()+1), title, text);
        notes.add(note);
        return note;
    }

    public Note getNoteById(Long id) {
        return notes.stream().filter(element -> id.equals(element.getId())).findFirst().orElse(null);
    }

    public Note updateNote(Long id, String title, String content) {
        Note note = notes.stream().filter(element -> id.equals(element.getId())).findFirst().orElse(null);
        if (note != null) {
            int index = notes.indexOf(note);
            note.setTitle(title);
            note.setContent(content);
            notes.set(index,note);
            return note;
        }
        else {
            return null;
        }
    }

    public void deleteNote(Long id) {
        Note note = notes.stream().filter(element -> id.equals(element.getId())).findFirst().orElse(null);
        if (note != null) {
            notes.remove(note);
        }
    }
}