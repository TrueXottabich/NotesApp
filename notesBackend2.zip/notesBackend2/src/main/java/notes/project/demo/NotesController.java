package notes.project.demo;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class NotesController {

    private NotesRepository repository;

    public NotesController() {
        super();
        repository = NotesRepository.getInstance();
    }

    @PostMapping(value = "/notes")
    public Note addNewNote(@RequestBody NewNoteForm newNoteForm) {
        return repository.addNewNote(newNoteForm.getTitle(), newNoteForm.getContent());
    }

    @GetMapping(value = "/notes")
    public List<Note> getAllNotes() {
        return repository.getAllNotes();
    }

    @GetMapping("/notes/{id}")
    public Note getNoteById(@PathVariable Long id) {
        return repository.getNoteById(id);
    }

    @PutMapping("/notes/{id}")
    public Note updateNote(@PathVariable Long id, @RequestBody NewNoteForm newNoteForm) {
        return repository.updateNote(id,newNoteForm.getTitle(), newNoteForm.getContent());
    }

    @GetMapping(value = "/notes", params = {"query"})
    public List<Note> getNotesByText(@RequestParam("query")String text) {
        return repository.getNotesByText(text);
    }

    @DeleteMapping("/notes/{id}")
    public void deleteNote(@PathVariable Long id) {
        repository.deleteNote(id);
    }
}