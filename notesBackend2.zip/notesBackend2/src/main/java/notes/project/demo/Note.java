package notes.project.demo;

public class Note {

    public static int firstNLettersOfTextIsTitle = 8;

    private Long id;
    private String title;
    private String content;

    Note() {}

    public Note(Long id, String title, String text) {
        this.setId(id);
        this.setTitle(title);
        this.setContent(text);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        if (title == null || title.length() == 0) {
            if (content.length() > firstNLettersOfTextIsTitle) {
                return content.substring(0,firstNLettersOfTextIsTitle);
            } else {
                return content;
            }
        }
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
